import math
import numpy as np
import matplotlib.pyplot as plt
import cv2
from PIL import Image
from scipy.ndimage import label

def load_ground_truth_masks(ground_truth_masks):
  #loading the masks from gt image
    loaded_masks = []
    mask_image = Image.open(ground_truth_masks).convert('L')
    mask_array = np.array(mask_image)
    return mask_array

def compute_iou(predicted_masks , ground_truth_masks):
  combined_predicted_mask = np.any(predicted_masks.numpy(), axis=0)
  intersection = np.sum(np.logical_and(combined_predicted_mask , ground_truth_masks))
  union = np.sum(np.logical_or(combined_predicted_mask , ground_truth_masks))
  iou = intersection / union
  return iou

def compute_accuracy(predicted_mask , ground_truth_mask):
  combined_predicted_mask = np.any(predicted_mask.numpy(), axis=0)
  true_positives = np.sum(np.logical_and(combined_predicted_mask, ground_truth_mask))
  true_negatives = np.sum(np.logical_and(np.logical_not(combined_predicted_mask), np.logical_not(ground_truth_mask)))
  total_predictions = ground_truth_mask.size
  accuracy = (true_positives + true_negatives) / total_predictions
  return accuracy

def extract_and_resize_masks(image_path, target_shape=(512, 512)):
    image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    image = cv2.resize(image, target_shape)
    _, binary_mask = cv2.threshold(image, 127, 255, cv2.THRESH_BINARY)
    labeled_array, num_features = label(binary_mask)
    masks = [(labeled_array == i).astype(np.uint8) for i in range(1, num_features + 1)]
    return masks

def mask_IoU(maskA, maskB):
    intersection = np.logical_and(maskA, maskB)
    union = np.logical_or(maskA, maskB)
    iou = np.sum(intersection) / np.sum(union)
    return iou

class MaskMatchingAlgorithm:
    def __init__(self, gt_masks, pred_masks, iou_threshold=0.5):
        self.gt_masks = extract_and_resize_masks(gt_masks)
        self.pred_masks = pred_masks.cpu().numpy()
        self.iou_threshold = iou_threshold

    def matching(self):
        if len(self.pred_masks) == 0 or len(self.gt_masks) == 0:
            return [], [], [], [], [], []

        # Compute IoU matrix in a vectorized manner
        iou_matrix = np.array([[mask_IoU(p, g) for g in self.gt_masks] for p in self.pred_masks])

        iou_list = []
        pred_matched = set()
        gt_matched = set()
        tp_pred_indices = []
        tp_gt_indices = []

        while True:
            max_iou = np.max(iou_matrix)
            if max_iou < self.iou_threshold:
                break
            max_index = np.unravel_index(np.argmax(iou_matrix), iou_matrix.shape)
            iou_list.append(max_iou)
            pred_matched.add(max_index[0])
            gt_matched.add(max_index[1])

            tp_pred_indices.append(max_index[0])
            tp_gt_indices.append(max_index[1])
            #print(
              #f"Matched predicted mask {max_index[0]} with GT mask {max_index[1]}, IoU = {max_iou}")
            iou_matrix[max_index[0], :] = 0
            iou_matrix[:, max_index[1]] = 0

        unmatched_pred_iou = [0] * len([i for i in range(len(self.pred_masks)) if i not in pred_matched])
        unmatched_gt_iou = [0] * len([i for i in range(len(self.gt_masks)) if i not in gt_matched])
        iou_list.extend(unmatched_pred_iou)
        iou_list.extend(unmatched_gt_iou)
        for i in set(range(len(self.pred_masks))) - pred_matched:
            iou_list.append(0)
            #print(f"Unmatched predicted mask {i} has no match, IoU = 0, F1 = 0")

        # Print unmatched ground truth masks
        for i in set(range(len(self.gt_masks))) - gt_matched:
            iou_list.append(0)
            #print(f"Unmatched GT mask {i} has no match, IoU = 0, F1 = 0")
        fp_indices = list(set(range(len(self.pred_masks))) - pred_matched)
        fn_indices = list(set(range(len(self.gt_masks))) - gt_matched)

        return iou_list, tp_pred_indices, tp_gt_indices, fp_indices, fn_indices

    def tp_iou(self, tp_pred_indices, tp_gt_indices):
        tp_iou_list = [mask_IoU(self.pred_masks[i], self.gt_masks[j]) for i, j in zip(tp_pred_indices, tp_gt_indices)]
        avg_tp_iou = np.mean(tp_iou_list) if tp_iou_list else None
        return tp_iou_list, avg_tp_iou

    def display_results(self , iou_list ,tp_pred_indices,tp_gt_indices,fp_indices,fn_indices ,tp_iou_list, avg_tp_iou ):
      average_iou = np.mean(iou_list)
      true_positives = len(tp_pred_indices)
      false_positives = len(fp_indices)
      false_negatives = len(fn_indices)
    #   print("true_positives" , true_positives)
    #   print("false_positives" , false_positives)
    #   print("false_negatives" , false_negatives)
      if (true_positives + false_positives) != 0:
            precision = true_positives / (true_positives + false_positives)
      else:
            precision = 0.0

      if (true_positives + false_negatives) != 0:
            recall = true_positives / (true_positives + false_negatives)
      else:
            recall = 0.0

      if (precision + recall) != 0:
            f1_score = 2 * average_iou / (average_iou + 1)
      else:
            f1_score = 0.0

      tp_f1 = 2 * avg_tp_iou / (avg_tp_iou + 1)
      return average_iou, avg_tp_iou , precision , recall , f1_score , tp_f1



def display_images_with_masks(image, masks ,boxes , gt_masks):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 6))
    ax1.axis('off')
    ax1.imshow(image)
    ax1.set_title('Original Image')

    ax2.axis('off')
    ax2.imshow(image)
    ax2.set_title('Image with Masks')

    num_masks = masks.shape[0]
    for i in range(num_masks):
        mask = masks[i].numpy()
        mask = np.ma.masked_where(mask < 0.5, mask)
        ax2.imshow(mask, alpha=0.5, cmap='jet')

    # iou = compute_iou(masks , gt_masks)
    # accuracy = compute_accuracy(masks, gt_masks)
    # Adjust spacing between subplots
    plt.tight_layout()

    # Display the figure in the notebook
    plt.show()
    # iou_list, f1_scores, tp_pred_indices, tp_gt_indices, fp_indices, fn_indices = matching(boxes , gt_masks)
    # tp_iou_list, avg_tp_iou = tp_iou(boxes, gt_masks, tp_pred_indices, tp_gt_indices)
    # print("average iou:", np.mean(iou_list))
    # print("average f_Score:", np.mean(f1_scores))
    # print("True Positive IoUs:", tp_iou_list)
    # print("avgerage tp_iou:", avg_tp_iou)
     